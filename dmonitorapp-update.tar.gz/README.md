# DMonitorApp - Система мониторинга сервисов

Spring Boot приложение для мониторинга здоровья HTTP и Database сервисов с использованием WebFlux и R2DBC.

## 🚀 Возможности
- Мониторинг HTTP сервисов (GET запросы)
- Мониторинг подключений к базам данных (PostgreSQL)
- Реактивный стек (Spring WebFlux, R2DBC)
- Автоматические проверки по расписанию
- REST API для управления конфигурацией
- Сохранение результатов в PostgreSQL

## 📦 Требования
- Java 21
- Docker & Docker Compose
- PostgreSQL 16+

## ⚡ Быстрый старт

### 1. Запуск базы данных
\`\`\`bash
docker-compose up -d monitor-db
\`\`\`

### 2. Запуск приложения
\`\`\`bash
export JAVA_HOME=/opt/homebrew/Cellar/openjdk@21/21.0.9/libexec/openjdk.jdk/Contents/Home
./gradlew bootRun
\`\`\`

### 3. Проверка работы
\`\`\`bash
curl http://localhost:8080/api/monitoring/status
\`\`\`
