package com.pashkevich.dmonitorapp.model;

public enum ServiceStatus {
    UP,
    DOWN,
    DEGRADED,
    UNKNOWN,
    TIMEOUT
}
