package com.pashkevich.dmonitorapp.model;

public enum CheckType {
    HTTP,
    DATABASE,
    KAFKA,
    TCP,
    CUSTOM
}

